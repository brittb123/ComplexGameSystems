// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BedActor.h"
#include "MyBedActor.generated.h"

/**
 * 
 */
UCLASS()
class PROGRAMMINGDEMO_API AMyBedActor : public ABedActor
{
	GENERATED_BODY()
	
};
